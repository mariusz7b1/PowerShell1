﻿
$logFile = "C:\Logs\log.txt"


$logFile.Contains("C:")
$logFile.Contains("D:")

$logFile.Insert(7,"\MyScript")
$logFile

$logFile=$logFile.Insert(7,"\MyScript")
$logFile


$logFile.Replace(".txt",".htm")


$logFile.Split("\")


$logFile.ToUpper()
$logFile.ToLower()



