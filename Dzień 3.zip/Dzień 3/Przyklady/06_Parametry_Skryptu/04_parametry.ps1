﻿Param (
    [Parameter(Mandatory=$true)][string]$napis
    )

Write-Host "Wartość parametru to: $napis" -NoNewline -BackgroundColor Black -ForegroundColor Green

