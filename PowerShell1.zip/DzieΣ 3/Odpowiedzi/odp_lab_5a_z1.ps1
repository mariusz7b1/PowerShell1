﻿param(
    [string]$Tekst
)
Write-Host "Wypisuję parametr Tekst: $Tekst"
