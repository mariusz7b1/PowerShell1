﻿param(
    [string]$Imie,
    [string]$Nazwisko,
    [int]$Wiek
)
Write-Host "Mam na imię $Imie $Nazwisko i mam $Wiek lat."
