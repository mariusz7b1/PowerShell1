﻿# to jest przykład komendy w wielu liniach 
get-process | where `
 {$_.id -lt ` 
 3000}

 <#
 i komentarza wielolinijkowego 
 znaczek gravis `  ten z tylą klawiszu został‚ wykorzystany:)
 
 #>