﻿#MODULE

Get-Module
Get-NetIPConfiguration

Get-Module
Get-Module -ListAvailable

Remove-Module NetTCPIP

Import-Module NetTCPIP 
Get-Module


#https://www.powershellgallery.com/


